function updateClock() {
  const el = document.getElementById('liveTime');
  if (!el) return;
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  el.textContent = timeStr + ' LOCAL';
}
updateClock();
setInterval(updateClock, 30000);
