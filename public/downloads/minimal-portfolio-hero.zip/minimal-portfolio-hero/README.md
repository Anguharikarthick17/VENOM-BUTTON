# Minimal Editorial Agency Hero Section
**Free Frontend Resource by GENZLOG (https://genzlog.com)**

A modern, bold editorial hero component featuring live status availability indicator, responsive typographic scale, CTA buttons, and a key stat metric row.

## Features
- Scaled headline typography using `clamp()`
- Live availability indicator dot with CSS pulse
- Dual CTA buttons (Primary & Secondary action paths)
- Metric stats row
- Pure HTML, CSS, & Vanilla JS

## License
MIT License. Free for personal & commercial use with attribution to GENZLOG.
