# Animated Split-Screen Login Page
**Free Frontend Resource by GENZLOG (https://genzlog.com)**

A modern, responsive split-screen authentication page featuring an editorial brand panel, sleek form controls, floating labels, password reveal toggle, and responsive mobile adaptations.

## Features
- Split-screen layout (Hero brand panel + form panel)
- Responsive mobile adaptation (gracefully collapses on mobile)
- Password visibility show/hide toggle
- Pure HTML5, CSS3, and Vanilla JavaScript (zero external dependencies)
- Styled with dark mode aesthetics (#050505 background with #FFFFFF crisp monochrome accents)
- Accessible form labeling and ARIA attributes

## Quick Start
1. Extract this ZIP archive into your project directory.
2. Open `index.html` directly in any modern browser.
3. To customize colors, update the CSS custom properties in `:root` inside `style.css`.

## Customization Guide
- **Brand Name & Logo**: Edit the `.brand-logo` container in `index.html`.
- **Colors**: Open `style.css` and modify `--accent-primary` and `--bg-primary`.
- **Backend API**: In `script.js`, replace the `setTimeout` simulation in the form submit handler with your actual `fetch()` or Supabase/Firebase auth call.

## License
Released under the MIT License. Free for both personal and commercial use with attribution to GENZLOG.
