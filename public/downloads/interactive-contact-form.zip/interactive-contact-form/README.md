# Validated Business Inquiry & Contact Form
**Free Frontend Resource by GENZLOG (https://genzlog.com)**

A modern client lead-generation contact form with interactive service chip pills, budget tier selection, floating inputs, and client-side validation.

## Features
- Interactive service requirement selector chips
- Budget tier selector chips
- Responsive grid layout
- Vanilla JavaScript validation
- Ready for integration with Web3Forms, Formspree, or custom API endpoints

## License
MIT License. Free for personal & commercial use with attribution to GENZLOG.
