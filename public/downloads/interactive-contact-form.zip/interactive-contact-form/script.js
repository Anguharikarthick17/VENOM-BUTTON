document.addEventListener('DOMContentLoaded', () => {
  // Setup chip click selectors
  setupChips('serviceChips', 'selectedService');
  setupChips('budgetChips', 'selectedBudget');

  function setupChips(containerId, hiddenInputId) {
    const container = document.getElementById(containerId);
    const hiddenInput = document.getElementById(hiddenInputId);
    if (!container || !hiddenInput) return;

    const chips = container.querySelectorAll('.chip');
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        hiddenInput.value = chip.getAttribute('data-value');
      });
    });
  }

  // Handle Form Submission
  const form = document.getElementById('inquiryForm');
  const alertEl = document.getElementById('statusAlert');
  const submitBtn = document.getElementById('submitBtn');

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('clientName').value.trim();
      const email = document.getElementById('clientEmail').value.trim();
      const service = document.getElementById('selectedService').value;
      const budget = document.getElementById('selectedBudget').value;

      if (!name || !email) return;

      submitBtn.disabled = true;
      submitBtn.textContent = 'Transmitting inquiry...';

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Send Project Inquiry ↗';
        alertEl.textContent = `Inquiry recorded for ${name}! We will review your ${service} inquiry (${budget}) and reply via ${email}.`;
        alertEl.style.display = 'block';
        form.reset();
      }, 700);
    });
  }
});
