document.addEventListener('DOMContentLoaded', () => {
  const billingToggle = document.getElementById('billingToggle');
  const amountEls = document.querySelectorAll('.amount');

  let isAnnual = false;

  if (billingToggle) {
    billingToggle.addEventListener('click', () => {
      isAnnual = !isAnnual;
      billingToggle.classList.toggle('annual', isAnnual);

      amountEls.forEach(el => {
        const targetValue = isAnnual ? el.getAttribute('data-annual') : el.getAttribute('data-monthly');
        el.textContent = targetValue;
      });
    });
  }
});
