# Modern SaaS Pricing Cards with Monthly/Annual Toggle
**Free Frontend Resource by GENZLOG (https://genzlog.com)**

An eye-catching, responsive pricing table component with a smooth Monthly vs Annual billing switch, glowing featured card, feature checklists, and dark-mode styling.

## Features
- Dynamic price toggling between monthly & annual rates
- Highlighted "Most Popular" card with crisp white border and badge
- Responsive grid (adjusts cleanly on mobile, tablet, and desktop)
- Semantic list structure with active/disabled feature indicators
- Zero dependencies (vanilla HTML, CSS, JavaScript)

## Quick Start
1. Unzip into your project directory.
2. Open `index.html` in a browser.
3. Configure your tiers and prices using the `data-monthly` and `data-annual` attributes on `.amount`.

## License
MIT License. Free for personal & commercial use with attribution to GENZLOG.
