# 10 Creative Button Micro-Interactions
**Free Frontend Resource by GENZLOG (https://genzlog.com)**

A modular collection of 10 modern CSS button animations designed for high click-through rates and sleek visual appeal.

## Styles Included
1. `.btn-glow` — Signature magnetic ambient glow
2. `.btn-glitch` — Cyberpunk skewed hover effect
3. `.btn-beam` — Top border glowing beam sweep
4. `.btn-3d` — Tactile 3D press button with real depth
5. `.btn-shimmer` — Smooth linear gradient background sweep
6. `.btn-slide` — Micro-interaction icon offset
7. `.btn-pulse` — Live radar status pulse dot
8. `.btn-underline` — Minimal expanding underline
9. `.btn-glass` — Glassmorphism frosted acrylic button
10. `.btn-neon` — High-contrast neon fill inverter

## Usage
Simply copy the desired CSS class into your stylesheet and attach it to any `<button>` or `<a>` element.

## License
MIT License. Free for personal & commercial use with attribution to GENZLOG.
