# Responsive Glassmorphism Navigation Bar
**Free Frontend Resource by GENZLOG (https://genzlog.com)**

A modern navigation bar component with frosted glass blur upon scrolling, responsive mobile slide-out menu, hover micro-interactions, and pure vanilla CSS/JavaScript.

## Features
- Sticky fixed navigation
- Frosted glass effect activates on scroll (`backdrop-filter: blur(16px)`)
- Fully responsive mobile drawer with animated hamburger icon
- Zero external CSS or JavaScript libraries required
- Accessible keyboard and mobile touch support

## Setup
1. Include `style.css` in your HTML `<head>`.
2. Include the `<header class="navbar">` markup.
3. Link `script.js` right before `</body>`.

## License
MIT License. Free for personal & commercial use with attribution to GENZLOG.
